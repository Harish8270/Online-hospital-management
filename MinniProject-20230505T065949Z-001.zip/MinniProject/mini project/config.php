<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "mini_project";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbname);
?>